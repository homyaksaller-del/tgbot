import logging
import asyncio
import aiohttp
from aiogram import Router, F
from aiogram.types import CallbackQuery, Message, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.enums import ParseMode

from config import ADMIN_IDS
from database import pb_get_user, pb_register, pb_unregister, pb_get_all_users, is_valid_pb_key, is_valid_pb_key_format

logger = logging.getLogger(__name__)
pulsebot_router = Router()

FLASK_URL = "http://127.0.0.1:5000"

# ─── МОДУЛИ ───────────────────────────────────────────────────────
MODULES = {
    "shaxta":   ("⛏", "Шахта"),
    "stroyka":  ("🧱", "Стройка"),
    "port":     ("📦", "Порт"),
    "cow":      ("🐄", "Ферма"),
    "gym":      ("💪", "Качалка"),
    "cooking":  ("🍳", "Кулинария"),
    "demorgan": ("🔧", "Деморган"),
    "antiafk":  ("🤖", "Анти АФК"),
    "taxi":     ("🚕", "Авто КПК"),
    "wheel":    ("🎡", "Колесо"),
    "lottery":  ("🎰", "Лотерея"),
}

# Модули с режимами — показываем подменю перед запуском
GYM_MODES = {
    "bench":    "🏋 Жим лёжа",
    "expander": "💪 Эспандер",
}
COOKING_DISHES = [
    "🥤 Фруктовый смузи",
    "🥗 Фруктовый салат",
    "🥗 Овощной салат",
    "🥤 Овощной смузи",
    "🍲 Рагу",
]
# Маппинг отображение → API название
COOKING_MAP = {
    "🥤 Фруктовый смузи": "Фруктовый смузи",
    "🥗 Фруктовый салат": "Фруктовый салат",
    "🥗 Овощной салат":   "Овощной салат",
    "🥤 Овощной смузи":   "Овощной смузи",
    "🍲 Рагу":            "Рагу",
}


class PbRegState(StatesGroup):
    waiting_key = State()


def is_admin(user_id: int) -> bool:
    return user_id in ADMIN_IDS


# ─── API ──────────────────────────────────────────────────────────
async def pb_get(path: str) -> dict:
    try:
        async with aiohttp.ClientSession() as s:
            async with s.get(f"{FLASK_URL}{path}", timeout=aiohttp.ClientTimeout(total=5)) as r:
                return await r.json()
    except Exception as e:
        return {"error": str(e)}


async def pb_post(path: str, json: dict = None) -> dict:
    try:
        async with aiohttp.ClientSession() as s:
            async with s.post(f"{FLASK_URL}{path}", json=json or {}, timeout=aiohttp.ClientTimeout(total=5)) as r:
                return await r.json()
    except Exception as e:
        return {"error": str(e)}


# ─── KEYBOARDS ────────────────────────────────────────────────────
def main_menu_kb(modules: dict, admin: bool = False) -> InlineKeyboardMarkup:
    rows = []
    mod_list = list(MODULES.items())
    for i in range(0, len(mod_list), 2):
        row = []
        for mod_id, (icon, name) in mod_list[i:i+2]:
            active = modules.get(mod_id, {}).get("active", False)
            dot = "🟢" if active else "⚫️"
            row.append(InlineKeyboardButton(
                text=f"{dot} {icon} {name}",
                callback_data=f"pb_tap:{mod_id}"
            ))
        rows.append(row)

    rows.append([
        InlineKeyboardButton(text="🔄 Обновить", callback_data="pb_refresh"),
        InlineKeyboardButton(text="📊 Статистика", callback_data="pb_stats"),
    ])
    rows.append([InlineKeyboardButton(text="🛑 Остановить всё", callback_data="pb_stop_all")])

    if admin:
        rows.append([
            InlineKeyboardButton(text="👥 Пользователи", callback_data="pb_users_list"),
            InlineKeyboardButton(text="◀️ Админка", callback_data="admin_panel"),
        ])
    else:
        rows.append([InlineKeyboardButton(text="🚪 Выйти", callback_data="pb_logout")])

    return InlineKeyboardMarkup(inline_keyboard=rows)


def gym_mode_kb(current_active: bool) -> InlineKeyboardMarkup:
    rows = []
    if not current_active:
        # Выбор режима перед запуском
        for mode_id, mode_name in GYM_MODES.items():
            rows.append([InlineKeyboardButton(
                text=f"▶️ {mode_name}",
                callback_data=f"pb_gym_start:{mode_id}"
            )])
    else:
        rows.append([InlineKeyboardButton(text="⏹ Остановить", callback_data="pb_gym_start:stop")])

    rows.append([InlineKeyboardButton(text="◀️ Назад", callback_data="pb_refresh")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def cooking_kb(current_active: bool) -> InlineKeyboardMarkup:
    rows = []
    if not current_active:
        for dish_label in COOKING_DISHES:
            rows.append([InlineKeyboardButton(
                text=f"▶️ {dish_label}",
                callback_data=f"pb_cook_start:{dish_label}"
            )])
    else:
        rows.append([InlineKeyboardButton(text="⏹ Остановить", callback_data="pb_cook_start:stop")])

    rows.append([InlineKeyboardButton(text="◀️ Назад", callback_data="pb_refresh")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def reg_kb() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="Ввести ключ", callback_data="pb_enter_key", icon_custom_emoji_id="6041731551845159060")]
    ])


# ─── TEXTS ────────────────────────────────────────────────────────
def menu_text(modules: dict, game_active: bool) -> str:
    game_line = "🟢 Игра запущена" if game_active else "🔴 Игра не найдена"
    active = [f"{MODULES[mid][0]} {MODULES[mid][1]}" for mid in MODULES if modules.get(mid, {}).get("active")]
    if active:
        active_line = "Активны: " + ", ".join(active)
    else:
        active_line = "Активных ботов нет"
    return (
        f"🎮 <b>PulseBotz</b>\n\n"
        f"{game_line}\n"
        f"{active_line}"
    )


def stats_text(modules: dict) -> str:
    lines = ["📊 <b>Статистика</b>\n"]
    any_active = False
    for mod_id, (icon, name) in MODULES.items():
        info = modules.get(mod_id, {})
        if not info.get("active"):
            continue
        any_active = True
        counter = info.get("counter", 0)
        earned  = info.get("earned", 0)
        s = f"{icon} <b>{name}</b>  —  действий: <code>{counter}</code>"
        if earned:
            s += f",  заработано: <code>${earned}</code>"
        lines.append(s)
    if not any_active:
        lines.append("Нет активных ботов")
    return "\n".join(lines)


# ─── ACCESS CHECK ─────────────────────────────────────────────────
async def check_access(callback: CallbackQuery) -> bool:
    if is_admin(callback.from_user.id):
        return True
    user = await pb_get_user(callback.from_user.id)
    if user:
        return True
    await callback.answer("🔒 Нет доступа. Используй /remote", show_alert=True)
    return False


# ─── REGISTRATION ─────────────────────────────────────────────────
@pulsebot_router.message(Command("remote"))
async def cmd_remote(message: Message):
    user = await pb_get_user(message.from_user.id)
    if user or is_admin(message.from_user.id):
        data = await pb_get("/api/status")
        modules     = data.get("modules", {})
        game_active = data.get("game_active", False)
        admin       = is_admin(message.from_user.id)
        await message.answer(
            menu_text(modules, game_active),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_kb(modules, admin)
        )
        return

    await message.answer(
        "🎮 <b>PulseBotz — Удалённое управление</b>\n\n"
        "Для доступа нужен лицензионный ключ.",
        parse_mode=ParseMode.HTML,
        reply_markup=reg_kb()
    )


@pulsebot_router.callback_query(F.data == "pb_enter_key")
async def pb_enter_key(callback: CallbackQuery, state: FSMContext):
    await callback.message.edit_text(
        '<b><tg-emoji emoji-id="6041731551845159060">🔑</tg-emoji> Введи лицензионный ключ:</b>',
        parse_mode=ParseMode.HTML,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="Отмена", callback_data="pb_cancel_reg", icon_custom_emoji_id="5870657884844462243")]
        ])
    )
    await state.set_state(PbRegState.waiting_key)
    await callback.answer()


@pulsebot_router.callback_query(F.data == "pulsebot_entry")
async def pulsebot_entry(callback: CallbackQuery):
    """Вход из главного меню — для обычных пользователей."""
    user = await pb_get_user(callback.from_user.id)
    if user or is_admin(callback.from_user.id):
        data        = await pb_get("/api/status")
        modules     = data.get("modules", {})
        game_active = data.get("game_active", False)
        admin       = is_admin(callback.from_user.id)
        await callback.message.edit_text(
            menu_text(modules, game_active),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_kb(modules, admin)
        )
        await callback.answer()
        return

    await callback.message.edit_text(
        "🎮 <b>PulseBotz — Удалённое управление</b>\n\n"
        "Для доступа нужен лицензионный ключ.",
        parse_mode=ParseMode.HTML,
        reply_markup=reg_kb()
    )
    await callback.answer()


@pulsebot_router.callback_query(F.data == "pb_cancel_reg")
async def pb_cancel_reg(callback: CallbackQuery, state: FSMContext):
    await state.clear()
    from keyboards import main_menu_keyboard
    from handlers import WELCOME_TEXT
    await callback.message.edit_text(
        WELCOME_TEXT,
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_keyboard()
    )
    await callback.answer()


@pulsebot_router.message(PbRegState.waiting_key)
async def pb_process_key(message: Message, state: FSMContext):
    await state.clear()
    key = (message.text or "").strip()

    # Быстрая проверка формата
    if not is_valid_pb_key_format(key):
        await message.answer(
            f'<tg-emoji emoji-id="5870657884844462243">❌</tg-emoji> <b>Неверный формат ключа.</b>\n\n'
            "Пример: <code>Xr6D2W-wvm4Of-qRdltN-gvUlDf-lMhGXo-rMJLTQ</code>",
            parse_mode=ParseMode.HTML,
            reply_markup=reg_kb()
        )
        return

    # Проверка по базе
    ok, reason = await is_valid_pb_key(key, message.from_user.id)
    if not ok:
        error_msgs = {
            "not_found":  f'<tg-emoji emoji-id="5870657884844462243">❌</tg-emoji> <b>Ключ не найден.</b>\nПроверь правильность ключа.',
            "not_issued": f'<tg-emoji emoji-id="5870657884844462243">❌</tg-emoji> <b>Ключ ещё не активирован.</b>\nОбратись в поддержку.',
            "wrong_user": f'<tg-emoji emoji-id="5870657884844462243">❌</tg-emoji> <b>Этот ключ зарегистрирован на другого пользователя.</b>',
        }
        await message.answer(
            error_msgs.get(reason, f'<tg-emoji emoji-id="5870657884844462243">❌</tg-emoji> Ошибка проверки ключа.'),
            parse_mode=ParseMode.HTML,
            reply_markup=reg_kb()
        )
        return

    await pb_register(message.from_user.id, key, source="manual")
    data        = await pb_get("/api/status")
    modules     = data.get("modules", {})
    game_active = data.get("game_active", False)
    await message.answer(f'<tg-emoji emoji-id="5870633910337015697">✅</tg-emoji> <b>Ключ принят! Доступ открыт.</b>', parse_mode=ParseMode.HTML)
    await message.answer(
        menu_text(modules, game_active),
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_kb(modules, False)
    )


# ─── ADMIN ENTRY ──────────────────────────────────────────────────
@pulsebot_router.callback_query(F.data == "pb_logout")
async def pb_logout(callback: CallbackQuery):
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="Да, выйти", callback_data="pb_logout_confirm", icon_custom_emoji_id="5870633910337015697"),
            InlineKeyboardButton(text="Отмена", callback_data="pb_refresh", icon_custom_emoji_id="5870657884844462243"),
        ]
    ])
    await callback.message.edit_text(
        "🚪 <b>Выход из аккаунта</b>\n\n"
        "Ключ будет отвязан. Для повторного входа нужно снова ввести ключ.",
        parse_mode=ParseMode.HTML,
        reply_markup=kb
    )
    await callback.answer()


@pulsebot_router.callback_query(F.data == "pb_logout_confirm")
async def pb_logout_confirm(callback: CallbackQuery):
    await pb_unregister(callback.from_user.id)
    await callback.message.edit_text(
        f'<tg-emoji emoji-id="5870633910337015697">✅</tg-emoji> Вы вышли из аккаунта.\n\nДля повторного входа используй /remote',
        parse_mode=ParseMode.HTML
    )
    await callback.answer("Вышли успешно")


@pulsebot_router.callback_query(F.data == "pulsebot_panel")
async def pulsebot_panel(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return
    data        = await pb_get("/api/status")
    modules     = data.get("modules", {})
    game_active = data.get("game_active", False)
    await callback.message.edit_text(
        menu_text(modules, game_active),
        parse_mode=ParseMode.HTML,
        reply_markup=main_menu_kb(modules, admin=True)
    )
    await callback.answer()


# ─── TAP ON MODULE ────────────────────────────────────────────────
@pulsebot_router.callback_query(F.data.startswith("pb_tap:"))
async def pb_tap(callback: CallbackQuery):
    if not await check_access(callback):
        return
    mod_id  = callback.data.split(":", 1)[1]
    data    = await pb_get("/api/status")
    modules = data.get("modules", {})
    active  = modules.get(mod_id, {}).get("active", False)
    icon, name = MODULES.get(mod_id, ("", mod_id))

    # Модули с выбором режима
    if mod_id == "gym":
        await callback.message.edit_text(
            f"💪 <b>Качалка</b>\n\n"
            + ("Бот активен. Остановить?" if active else "Выбери режим:"),
            parse_mode=ParseMode.HTML,
            reply_markup=gym_mode_kb(active)
        )
        await callback.answer()
        return

    if mod_id == "cooking":
        await callback.message.edit_text(
            f"🍳 <b>Кулинария</b>\n\n"
            + ("Бот активен. Остановить?" if active else "Выбери блюдо:"),
            parse_mode=ParseMode.HTML,
            reply_markup=cooking_kb(active)
        )
        await callback.answer()
        return

    # Обычный toggle
    result = await pb_post(f"/api/{mod_id}/toggle")
    if "error" in result:
        await callback.answer(f"❌ {result['error']}", show_alert=True)
        return

    data        = await pb_get("/api/status")
    modules     = data.get("modules", {})
    game_active = data.get("game_active", False)
    admin       = is_admin(callback.from_user.id)
    now_active  = modules.get(mod_id, {}).get("active", False)
    await callback.answer(f"{icon} {name} {'▶️ запущен' if now_active else '⏹ остановлен'}")
    try:
        await callback.message.edit_text(
            menu_text(modules, game_active),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_kb(modules, admin)
        )
    except Exception:
        pass


# ─── GYM MODES ────────────────────────────────────────────────────
@pulsebot_router.callback_query(F.data.startswith("pb_gym_start:"))
async def pb_gym_start(callback: CallbackQuery):
    if not await check_access(callback):
        return
    mode = callback.data.split(":", 1)[1]

    data   = await pb_get("/api/status")
    active = data.get("modules", {}).get("gym", {}).get("active", False)

    if mode == "stop" or active:
        await pb_post("/api/gym/toggle")
        await callback.answer("⏹ Качалка остановлена")
    else:
        await pb_post("/api/gym/toggle", {"gym_mode": mode, "food_key": "k", "food_pause": 10})
        mode_name = GYM_MODES.get(mode, mode)
        await callback.answer(f"▶️ Качалка запущена — {mode_name}")

    data        = await pb_get("/api/status")
    modules     = data.get("modules", {})
    game_active = data.get("game_active", False)
    admin       = is_admin(callback.from_user.id)
    try:
        await callback.message.edit_text(
            menu_text(modules, game_active),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_kb(modules, admin)
        )
    except Exception:
        pass


# ─── COOKING DISHES ───────────────────────────────────────────────
@pulsebot_router.callback_query(F.data.startswith("pb_cook_start:"))
async def pb_cook_start(callback: CallbackQuery):
    if not await check_access(callback):
        return
    dish_label = callback.data.split(":", 1)[1]

    data   = await pb_get("/api/status")
    active = data.get("modules", {}).get("cooking", {}).get("active", False)

    if dish_label == "stop" or active:
        await pb_post("/api/cooking/toggle", {"dish": "Фруктовый смузи"})
        await callback.answer("⏹ Кулинария остановлена")
    else:
        dish_name = COOKING_MAP.get(dish_label, dish_label)
        await pb_post("/api/cooking/toggle", {"dish": dish_name})
        await callback.answer(f"▶️ Кулинария: {dish_label}")

    data        = await pb_get("/api/status")
    modules     = data.get("modules", {})
    game_active = data.get("game_active", False)
    admin       = is_admin(callback.from_user.id)
    try:
        await callback.message.edit_text(
            menu_text(modules, game_active),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_kb(modules, admin)
        )
    except Exception:
        pass


# ─── REFRESH ──────────────────────────────────────────────────────
@pulsebot_router.callback_query(F.data == "pb_refresh")
async def pb_refresh(callback: CallbackQuery):
    if not await check_access(callback):
        return
    data        = await pb_get("/api/status")
    modules     = data.get("modules", {})
    game_active = data.get("game_active", False)
    admin       = is_admin(callback.from_user.id)
    try:
        await callback.message.edit_text(
            menu_text(modules, game_active),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_kb(modules, admin)
        )
    except Exception:
        pass
    await callback.answer("Обновлено ✓")


# ─── STATS ────────────────────────────────────────────────────────
@pulsebot_router.callback_query(F.data == "pb_stats")
async def pb_stats(callback: CallbackQuery):
    if not await check_access(callback):
        return
    data    = await pb_get("/api/status")
    modules = data.get("modules", {})
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад", callback_data="pb_refresh")]
    ])
    try:
        await callback.message.edit_text(stats_text(modules), parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception:
        pass
    await callback.answer()


# ─── STOP ALL ─────────────────────────────────────────────────────
@pulsebot_router.callback_query(F.data == "pb_stop_all")
async def pb_stop_all(callback: CallbackQuery):
    if not await check_access(callback):
        return
    data    = await pb_get("/api/status")
    modules = data.get("modules", {})
    stopped = 0
    for mod_id in MODULES:
        if modules.get(mod_id, {}).get("active"):
            await pb_post(f"/api/{mod_id}/toggle")
            stopped += 1
            await asyncio.sleep(0.3)
    await callback.answer(f"🛑 Остановлено: {stopped}" if stopped else "Нет активных ботов", show_alert=True)
    data        = await pb_get("/api/status")
    modules     = data.get("modules", {})
    game_active = data.get("game_active", False)
    admin       = is_admin(callback.from_user.id)
    try:
        await callback.message.edit_text(
            menu_text(modules, game_active),
            parse_mode=ParseMode.HTML,
            reply_markup=main_menu_kb(modules, admin)
        )
    except Exception:
        pass


# ─── ADMIN: USERS LIST ────────────────────────────────────────────
@pulsebot_router.callback_query(F.data == "pb_users_list")
async def pb_users_list(callback: CallbackQuery):
    if not is_admin(callback.from_user.id):
        await callback.answer("❌ Нет доступа", show_alert=True)
        return
    users = await pb_get_all_users(limit=50)
    if not users:
        text = "👥 <b>Пользователи PulseBotz</b>\n\nНет зарегистрированных."
    else:
        lines = [f"👥 <b>Пользователи ({len(users)})</b>\n"]
        for u in users:
            src = "🛒" if u["source"] == "tg_shop" else '<tg-emoji emoji-id="6041731551845159060">🔑</tg-emoji>'
            lines.append(f"{src} <code>{u['user_id']}</code>\n<code>{u['license_key']}</code>")
        text = "\n\n".join(lines)
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="◀️ Назад", callback_data="pulsebot_panel")]
    ])
    try:
        await callback.message.edit_text(text, parse_mode=ParseMode.HTML, reply_markup=kb)
    except Exception:
        pass
    await callback.answer()