"""
Дозаполняет кастомные эмодзи из набора https://t.me/addemoji/tgiosicons

Что уже сделано без запуска этого скрипта (в чате с Claude):
  - Все эмодзи, для которых ID уже был известен из вашего же кода
    (✅ ❌ ℹ️ ⚙️ 🎉 🏷 🔒 📊 👤 ⏰ 🔗 🪙 ✍ 🤖 🛒 🔄 ✏, а также "Назад" / "На главную")
    обёрнуты в <tg-emoji emoji-id="...">...</tg-emoji> во всех местах,
    где сообщение реально отправляется с parse_mode=ParseMode.HTML.
  - Тексты алертов (callback.answer(..., show_alert=True)) НЕ трогались —
    всплывающие уведомления Telegram не поддерживают HTML/кастомные эмодзи в принципе.
  - В кнопках (keyboards.py) убраны задвоения "эмодзи в тексте + такая же иконка отдельно".

Что делает этот скрипт (нужен реальный доступ к api.telegram.org, которого нет
в песочнице, поэтому запустите его сами):
  1. Читает BOT_TOKEN из .env
  2. Запрашивает у Telegram полный список стикеров (кастомных эмодзи) набора tgiosicons
  3. Для каждого эмодзи, который в коде ещё остался "обычным" (🏦 💳 🔑 📦 🌍 ⏳ 📋 ⚠ ❓
     ➕ 👮 💵 📅 📌 📎 📭 🖋 🗑 📛 📸 🪪 🔐 → ✨ 📝 ◀ ▶ и т.п.), ищет его custom_emoji_id
     в наборе и подставляет — в текстах сообщений оборачивает в <tg-emoji>,
     в кнопках keyboards.py переносит в icon_custom_emoji_id и убирает эмодзи из text.
  4. Печатает итоговый отчёт: что заменил, что не нашёл в наборе (останется обычным
     эмодзи — в наборе иконок может не быть подходящей картинки).

Использование:
    pip install requests python-dotenv --break-system-packages   # если ещё не стоит
    python3 apply_tgiosicons.py
"""
import os
import re
import sys
import json
import tokenize
import io

try:
    import requests
except ImportError:
    sys.exit("Нужен пакет requests: pip install requests --break-system-packages")

PACK_NAME = "tgiosicons"
TARGET_TEXT_FILES = ["handlers.py", "admin_handlers.py", "database.py"]
KEYBOARDS_FILE = "keyboards.py"

TG_TAG = re.compile(r'<tg-emoji emoji-id=[\'"]\d+[\'"]>.*?</tg-emoji>')


def load_bot_token():
    token = os.environ.get("BOT_TOKEN")
    if token:
        return token
    if os.path.exists(".env"):
        for line in open(".env", encoding="utf-8"):
            line = line.strip()
            if line.startswith("BOT_TOKEN="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
    sys.exit("Не найден BOT_TOKEN (ни в переменных окружения, ни в .env)")


def fetch_pack_map(bot_token, pack_name=PACK_NAME):
    url = f"https://api.telegram.org/bot{bot_token}/getStickerSet"
    resp = requests.get(url, params={"name": pack_name}, timeout=20)
    data = resp.json()
    if not data.get("ok"):
        sys.exit(f"Не удалось получить набор '{pack_name}': {data}")
    emoji_map = {}
    for st in data["result"]["stickers"]:
        cid = st.get("custom_emoji_id")
        emoji = st.get("emoji")
        if cid and emoji:
            emoji_map.setdefault(emoji, cid)
    return emoji_map


# ---------- уже проверенная логика простановки тегов в текстах сообщений ----------

def offset_table(src):
    offs = [0]
    for l in src.splitlines(keepends=True):
        offs.append(offs[-1] + len(l))
    return offs


def to_offset(offs, row, col):
    return offs[row - 1] + col


def find_call_spans(toks, offs):
    spans = []
    i = 0
    while i < len(toks):
        tok = toks[i]
        if tok.type == tokenize.OP and tok.string == '(':
            j = i - 1
            chain = []
            while j >= 0 and (toks[j].type == tokenize.NAME or (toks[j].type == tokenize.OP and toks[j].string == '.')):
                if toks[j].type == tokenize.NAME:
                    chain.append(toks[j].string)
                j -= 1
            chain.reverse()
            if len(chain) >= 2 and chain[-1] in ('answer', 'edit_text', 'send_message'):
                is_toast = (chain[-1] == 'answer' and len(chain) == 2 and chain[-2] == 'callback')
                depth = 1
                k = i + 1
                first_name_tok = None
                while k < len(toks) and depth > 0:
                    if not is_toast and first_name_tok is None and depth == 1:
                        if toks[k].type == tokenize.NAME:
                            first_name_tok = toks[k]
                        elif toks[k].type == tokenize.OP and toks[k].string != '(':
                            first_name_tok = False
                    if toks[k].type == tokenize.OP and toks[k].string == '(':
                        depth += 1
                    elif toks[k].type == tokenize.OP and toks[k].string == ')':
                        depth -= 1
                    k += 1
                start = to_offset(offs, *tok.start)
                end = to_offset(offs, *toks[k - 1].end)
                if not is_toast:
                    spans.append({'start': start, 'end': end, 'first_name_tok': first_name_tok})
        i += 1
    return spans


def get_func_spans(src, offs):
    spans = []
    lines = src.splitlines(keepends=True)
    starts = [i for i, line in enumerate(lines) if re.match(r'^(async )?def \w', line)]
    starts.append(len(lines))
    for a, b in zip(starts, starts[1:]):
        spans.append((offs[a], offs[b]))
    return spans


def convert_text_file(path, id_map):
    src = open(path, encoding="utf-8").read()
    toks = list(tokenize.generate_tokens(io.StringIO(src).readline))
    offs = offset_table(src)
    call_spans = find_call_spans(toks, offs)
    func_spans = get_func_spans(src, offs)

    alts = sorted(id_map.keys(), key=len, reverse=True)
    if not alts:
        return 0, set()
    emoji_re = re.compile("(" + "|".join(re.escape(a) for a in alts) + ")(\ufe0f)?")

    html_regions = []
    for cs in call_spans:
        call_text = src[cs['start']:cs['end']]
        if 'ParseMode.HTML' not in call_text:
            continue
        html_regions.append((cs['start'], cs['end']))
        fnt = cs['first_name_tok']
        if fnt:
            varname = fnt.string
            fspan = next(((s, e) for s, e in func_spans if s <= cs['start'] < e), None)
            if fspan:
                fs, fe = fspan
                for m in re.finditer(rf'(?m)^([ \t]*){re.escape(varname)}\s*[:+]?=\s*(?!=)', src[fs:fe]):
                    eq_end = fs + m.end()
                    idx = None
                    for ti, t in enumerate(toks):
                        if to_offset(offs, *t.start) >= eq_end:
                            idx = ti
                            break
                    if idx is None:
                        continue
                    depth = 0
                    kk = idx
                    stmt_end = None
                    while kk < len(toks):
                        t = toks[kk]
                        if t.type == tokenize.OP and t.string in '([{':
                            depth += 1
                        elif t.type == tokenize.OP and t.string in ')]}':
                            depth -= 1
                        elif t.type == tokenize.NEWLINE and depth <= 0:
                            stmt_end = to_offset(offs, *t.start)
                            break
                        kk += 1
                    if stmt_end:
                        html_regions.append((eq_end, stmt_end))

    def in_html(pos):
        return any(s <= pos < e for s, e in html_regions)

    edits = []
    found_unmapped = set()
    n = 0
    fstring_quote_stack = []
    for tok in toks:
        if tok.type == tokenize.FSTRING_START:
            fstring_quote_stack.append(tok.string[-1])
        elif tok.type == tokenize.FSTRING_END:
            if fstring_quote_stack:
                fstring_quote_stack.pop()
        elif tok.type in (tokenize.FSTRING_MIDDLE, tokenize.STRING):
            if tok.type == tokenize.FSTRING_MIDDLE:
                q = fstring_quote_stack[-1] if fstring_quote_stack else '"'
                start = to_offset(offs, *tok.start)
                end = to_offset(offs, *tok.end)
            else:
                s = tok.string
                m = re.match(r'^[a-zA-Z]*', s)
                rest = s[m.end():]
                q = rest[0]
                qlen = 3 if rest[:3] in ('"""', "'''") else 1
                start = to_offset(offs, *tok.start) + m.end() + qlen
                end = to_offset(offs, *tok.end) - qlen
            if not in_html(start):
                continue
            text = src[start:end]
            placeholders = {}

            def mask(mm):
                key = f"\uE000{len(placeholders)}\uE001"
                placeholders[key] = mm.group(0)
                return key

            masked = TG_TAG.sub(mask, text)
            attr_q = "'" if q == '"' else '"'

            def repl(m):
                nonlocal n
                base = m.group(1)
                vs = m.group(2) or ""
                cid = id_map.get(base)
                if not cid:
                    found_unmapped.add(base)
                    return m.group(0)
                n += 1
                return f'<tg-emoji emoji-id={attr_q}{cid}{attr_q}>{base}{vs}</tg-emoji>'

            new_masked = emoji_re.sub(repl, masked)
            for key, val in placeholders.items():
                new_masked = new_masked.replace(key, val)
            if new_masked != text:
                edits.append((start, end, new_masked))

    edits.sort(key=lambda e: e[0])
    out, last = [], 0
    for s, e, rep in edits:
        if s < last:
            continue
        out.append(src[last:s])
        out.append(rep)
        last = e
    out.append(src[last:])
    new_src = "".join(out)
    if new_src != src:
        open(path, "w", encoding="utf-8").write(new_src)
    return n, found_unmapped


# ---------- кнопки: emoji в text -> icon_custom_emoji_id ----------

BUTTON_RE = re.compile(
    r'InlineKeyboardButton\(\s*text=(f?)(["\'])([^"\']*)\2([^)]*?)\)',
    re.S
)
EMOJI_PREFIX_RE = re.compile(r'^([^\w\s,.!?()<>]{1,2})\s*(.*)$', re.S)


def convert_keyboards_file(path, id_map):
    src = open(path, encoding="utf-8").read()
    n = 0
    unmapped = set()

    def repl(m):
        nonlocal n
        fprefix, quote, text, tail = m.groups()
        if 'icon_custom_emoji_id' in tail:
            return m.group(0)
        pm = EMOJI_PREFIX_RE.match(text)
        if not pm:
            return m.group(0)
        emoji, rest = pm.groups()
        base = emoji.rstrip("\ufe0f")
        if base not in id_map or not rest.strip():
            if base and ord(base[0]) > 0x2000:
                unmapped.add(base)
            return m.group(0)
        cid = id_map[base]
        n += 1
        new_tail = tail.rstrip()
        if new_tail and not new_tail.endswith(','):
            new_tail += ','
        return f'InlineKeyboardButton(text={fprefix}{quote}{rest}{quote}{new_tail}\n                              icon_custom_emoji_id="{cid}")'

    new_src = BUTTON_RE.sub(repl, src)
    if new_src != src:
        open(path, "w", encoding="utf-8").write(new_src)
    return n, unmapped


def main():
    token = load_bot_token()
    print(f"Запрашиваю набор '{PACK_NAME}'...")
    pack_map = fetch_pack_map(token)
    print(f"Получено {len(pack_map)} эмодзи из набора.\n")

    total_converted = 0
    all_unmapped = set()

    for fname in TARGET_TEXT_FILES:
        if not os.path.exists(fname):
            continue
        n, unmapped = convert_text_file(fname, pack_map)
        total_converted += n
        all_unmapped |= unmapped
        print(f"{fname}: заменено {n}")

    if os.path.exists(KEYBOARDS_FILE):
        n, unmapped = convert_keyboards_file(KEYBOARDS_FILE, pack_map)
        total_converted += n
        all_unmapped |= unmapped
        print(f"{KEYBOARDS_FILE}: заменено {n}")

    print(f"\nИтого заменено: {total_converted}")
    if all_unmapped:
        print("\nНе нашлось в наборе (остались обычным эмодзи):")
        print(" ".join(sorted(all_unmapped)))
        print("Если в наборе tgiosicons есть похожая иконка под другим кодом эмодзи,")
        print("добавьте её вручную в pack_map или замените эмодзи в коде на тот, что есть в наборе.")

    for fname in TARGET_TEXT_FILES + [KEYBOARDS_FILE]:
        if os.path.exists(fname):
            os.system(f"python3 -m py_compile {fname}")
    print("\nСинтаксис файлов проверен (py_compile).")


if __name__ == "__main__":
    main()
