import sqlite3

DB_PATH = "bot_database.db"

conn = sqlite3.connect(DB_PATH)
cur = conn.cursor()

cur.execute("DELETE FROM available_keys WHERE status = 'available'")
deleted = cur.rowcount
conn.commit()

print(f"Удалено доступных ключей: {deleted}")

print("Осталось по статусам:")
for row in cur.execute("SELECT status, COUNT(*) FROM available_keys GROUP BY status"):
    print(f"  {row[0]}: {row[1]}")

conn.close()
